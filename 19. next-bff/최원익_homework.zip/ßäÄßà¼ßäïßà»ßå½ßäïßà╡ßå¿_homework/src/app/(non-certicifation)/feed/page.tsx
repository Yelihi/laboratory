import { MainPage } from "@/views/main/ui/Page";

const Page = () => {
  return <MainPage />;
};

export default Page;
